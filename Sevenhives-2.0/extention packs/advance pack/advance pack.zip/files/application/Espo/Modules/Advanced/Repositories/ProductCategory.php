<?php


namespace Espo\Modules\Advanced\Repositories;

class ProductCategory extends \Espo\Core\Repositories\CategoryTree
{
}
