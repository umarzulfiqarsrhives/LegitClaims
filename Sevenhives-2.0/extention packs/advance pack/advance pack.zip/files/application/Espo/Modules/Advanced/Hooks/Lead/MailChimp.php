<?php


namespace Espo\Modules\Advanced\Hooks\Lead;

class MailChimp extends \Espo\Modules\Advanced\Core\MailChimp\BaseRecipientHook
{

}

