<?php


namespace Espo\Modules\Advanced\Hooks\Account;

class MailChimp extends \Espo\Modules\Advanced\Core\MailChimp\BaseRecipientHook
{

}
