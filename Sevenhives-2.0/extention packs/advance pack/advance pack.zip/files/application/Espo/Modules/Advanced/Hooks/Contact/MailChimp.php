<?php


namespace Espo\Modules\Advanced\Hooks\Contact;

class MailChimp extends \Espo\Modules\Advanced\Core\MailChimp\BaseRecipientHook
{

}
