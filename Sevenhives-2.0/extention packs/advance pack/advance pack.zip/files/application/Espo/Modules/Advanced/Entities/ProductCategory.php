<?php


namespace Espo\Modules\Advanced\Entities;

class ProductCategory extends \Espo\Core\Templates\Entities\CategoryTree
{

}

