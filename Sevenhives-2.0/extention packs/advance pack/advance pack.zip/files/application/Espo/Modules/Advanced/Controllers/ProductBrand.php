<?php


namespace Espo\Modules\Advanced\Controllers;

class ProductBrand extends \Espo\Core\Controllers\Record
{

}
