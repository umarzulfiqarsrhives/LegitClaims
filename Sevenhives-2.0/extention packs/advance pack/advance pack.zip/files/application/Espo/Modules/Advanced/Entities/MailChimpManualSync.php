<?php


namespace Espo\Modules\Advanced\Entities;

class MailChimpManualSync extends \Espo\Core\ORM\Entity
{

}

