<?php


namespace Espo\Modules\Advanced\Entities;

class ShippingProvider extends \Espo\Core\ORM\Entity
{

}

