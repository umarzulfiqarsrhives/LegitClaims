<?php


namespace Espo\Modules\Advanced\Entities;

class Product extends \Espo\Core\ORM\Entity
{

}

