<?php


namespace Espo\Modules\Advanced\Core\Workflow\Conditions;

class BeforeToday extends Before
{

}