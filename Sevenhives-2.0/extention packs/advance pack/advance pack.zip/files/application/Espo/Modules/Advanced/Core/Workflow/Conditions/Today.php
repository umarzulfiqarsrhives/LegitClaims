<?php


namespace Espo\Modules\Advanced\Core\Workflow\Conditions;

class Today extends On
{

}