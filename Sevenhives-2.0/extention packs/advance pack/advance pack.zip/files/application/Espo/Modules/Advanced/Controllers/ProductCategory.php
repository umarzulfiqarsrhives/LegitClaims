<?php


namespace Espo\Modules\Advanced\Controllers;

class ProductCategory extends \Espo\Core\Templates\Controllers\CategoryTree
{

}
