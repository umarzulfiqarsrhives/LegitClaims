<?php


namespace Espo\Modules\Advanced\Entities;

class QuoteItem extends \Espo\Core\ORM\Entity
{

}

