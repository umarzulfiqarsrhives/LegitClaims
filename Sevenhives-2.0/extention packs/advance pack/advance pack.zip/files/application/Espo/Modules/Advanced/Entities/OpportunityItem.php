<?php


namespace Espo\Modules\Advanced\Entities;

class OpportunityItem extends \Espo\Core\ORM\Entity
{

}

