<?php


namespace Espo\Modules\Advanced\Controllers;

class Product extends \Espo\Core\Controllers\Record
{

}
