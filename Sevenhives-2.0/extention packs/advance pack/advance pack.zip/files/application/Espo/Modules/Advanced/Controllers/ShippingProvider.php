<?php


namespace Espo\Modules\Advanced\Controllers;

class ShippingProvider extends \Espo\Core\Controllers\Record
{

}
