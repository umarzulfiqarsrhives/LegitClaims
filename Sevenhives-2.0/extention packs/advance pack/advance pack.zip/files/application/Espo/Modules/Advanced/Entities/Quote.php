<?php


namespace Espo\Modules\Advanced\Entities;

class Quote extends \Espo\Core\ORM\Entity
{

}

