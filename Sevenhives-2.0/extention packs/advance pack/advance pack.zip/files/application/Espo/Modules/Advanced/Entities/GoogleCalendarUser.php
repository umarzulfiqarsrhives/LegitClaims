<?php


namespace Espo\Modules\Advanced\Entities;

class GoogleCalendarUser extends \Espo\Core\ORM\Entity
{

}

