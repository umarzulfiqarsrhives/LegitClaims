<?php


namespace Espo\Modules\Advanced\Entities;

class GoogleCalendarRecurrentEvent extends \Espo\Core\ORM\Entity
{

}

