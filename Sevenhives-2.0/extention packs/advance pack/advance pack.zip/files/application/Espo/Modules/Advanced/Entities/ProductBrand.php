<?php


namespace Espo\Modules\Advanced\Entities;

class ProductBrand extends \Espo\Core\ORM\Entity
{

}

