<?php


namespace Espo\Modules\Advanced\Entities;

class Workflow extends \Espo\Core\ORM\Entity
{

}
