<?php


namespace Espo\Modules\Advanced\Entities;

class MailChimpLogMarker extends \Espo\Core\ORM\Entity
{

}

