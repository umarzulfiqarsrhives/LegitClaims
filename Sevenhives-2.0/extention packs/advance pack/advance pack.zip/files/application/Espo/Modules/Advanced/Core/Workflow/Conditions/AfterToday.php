<?php


namespace Espo\Modules\Advanced\Core\Workflow\Conditions;

class AfterToday extends After
{

}