<?php


namespace Espo\Modules\Advanced\Entities;

class Tax extends \Espo\Core\ORM\Entity
{

}

