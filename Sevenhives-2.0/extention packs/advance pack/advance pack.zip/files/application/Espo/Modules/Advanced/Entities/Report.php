<?php


namespace Espo\Modules\Advanced\Entities;

class Report extends \Espo\Core\ORM\Entity
{

}

