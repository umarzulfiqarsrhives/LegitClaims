<?php


namespace Espo\Modules\Advanced\Entities;

class GoogleCalendar extends \Espo\Core\ORM\Entity
{

}

