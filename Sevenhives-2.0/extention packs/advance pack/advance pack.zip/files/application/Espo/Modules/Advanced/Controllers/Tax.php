<?php


namespace Espo\Modules\Advanced\Controllers;

class Tax extends \Espo\Core\Controllers\Record
{

}
