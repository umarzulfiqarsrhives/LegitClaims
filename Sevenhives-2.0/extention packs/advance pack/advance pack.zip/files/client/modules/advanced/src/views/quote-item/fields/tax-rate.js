

Espo.define('Advanced:Views.QuoteItem.Fields.TaxRate', 'Views.Fields.Float', function (Dep) {

    return Dep.extend({

        detailTemplate: 'advanced:quote-item.fields.tax-rate.detail',

    });
});

