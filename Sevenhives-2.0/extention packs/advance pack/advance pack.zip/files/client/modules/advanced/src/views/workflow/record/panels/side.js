

Espo.define('Advanced:Views.Workflow.Record.Panels.Side', 'Views.Record.Panels.Side', function (Dep) {

    return Dep.extend({

        template: 'advanced:workflow.record.panels.side',

    });
});