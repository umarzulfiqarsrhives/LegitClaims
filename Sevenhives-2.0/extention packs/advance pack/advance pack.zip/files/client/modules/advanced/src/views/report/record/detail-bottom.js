

Espo.define('Advanced:Views.Report.Record.DetailBottom', 'Views.Record.DetailBottom', function (Dep) {

    return Dep.extend({

        afterRender: function () {

        },
        
        setup: function () {
            Dep.prototype.setup.call(this);
        },

    });

});

