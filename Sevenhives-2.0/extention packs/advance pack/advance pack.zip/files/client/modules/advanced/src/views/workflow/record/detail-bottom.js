

Espo.define('Advanced:Views.Workflow.Record.DetailBottom', 'Advanced:Views.Workflow.Record.EditBottom', function (Dep) {

    return Dep.extend({

        editMode: false

    });
});


