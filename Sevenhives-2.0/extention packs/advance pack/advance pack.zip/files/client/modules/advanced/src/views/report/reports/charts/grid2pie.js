

Espo.define('Advanced:Views.Report.Reports.Charts.Grid2Pie', 'Advanced:Views.Report.Reports.Charts.Base', function (Dep) {

    return Dep.extend({    
    
        prepareData: function () {            
            return null;
        },    
        
        drow: function () {
            var self = this;
        },
    });

});

