

Espo.define('Advanced:Views.MailChimp.Integration', 'Views.Admin.Integrations.Edit', function (Dep) {

    return Dep.extend({

    });

});
