

Espo.define('Advanced:Views.Workflow.Record.List', 'Views.Record.List', function (Dep) {

    return Dep.extend({

    	massActionList: ['remove', 'massUpdate'],

    });
});


