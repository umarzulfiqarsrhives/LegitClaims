

Espo.define('Advanced:Views.Report.Fields.DashletSelect', 'Views.Fields.Link', function (Dep) {

    return Dep.extend({

        createDisabled: true

    });

});

