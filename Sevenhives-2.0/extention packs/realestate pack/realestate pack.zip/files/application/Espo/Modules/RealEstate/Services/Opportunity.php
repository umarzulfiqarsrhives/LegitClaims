<?php


namespace Espo\Modules\RealEstate\Services;

class Opportunity extends \Espo\Modules\Crm\Services\Opportunity
{

}

