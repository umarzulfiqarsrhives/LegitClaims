<?php


namespace Espo\Modules\RealEstate\Entities;

class Contact extends \Espo\Modules\Crm\Entities\Contact
{

}

