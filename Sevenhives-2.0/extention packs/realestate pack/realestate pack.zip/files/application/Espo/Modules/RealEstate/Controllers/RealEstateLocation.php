<?php


namespace Espo\Modules\RealEstate\Controllers;

class RealEstateLocation extends \Espo\Core\Templates\Controllers\CategoryTree
{

}
