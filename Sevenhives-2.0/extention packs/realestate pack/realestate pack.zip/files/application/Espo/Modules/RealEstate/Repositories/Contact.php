<?php


namespace Espo\Modules\RealEstate\Repositories;

class Contact extends \Espo\Modules\Crm\Repositories\Contact
{

}

