<?php

namespace Espo\Modules\RealEstate\Entities;

class RealEstateRequest extends \Espo\Core\Templates\Entities\Base
{
    protected $entityType = "RealEstateRequest";
}
