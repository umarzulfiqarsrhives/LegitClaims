<?php


namespace Espo\Modules\RealEstate\Entities;

class RealEstateLocation extends \Espo\Core\Templates\Entities\CategoryTree
{

}

