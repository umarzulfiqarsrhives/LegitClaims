<?php

namespace Espo\Modules\RealEstate\Entities;

class RealEstateProperty extends \Espo\Core\Templates\Entities\Base
{
    protected $entityType = "RealEstateProperty";
}
