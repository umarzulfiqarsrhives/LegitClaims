<?php


namespace Espo\Modules\RealEstate\Services;

class Contact extends \Espo\Modules\Crm\Services\Contact
{

}

