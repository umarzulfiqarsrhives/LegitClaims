<?php


namespace Espo\Modules\RealEstate\SelectManagers;

class Contact extends \Espo\Core\SelectManagers\Base
{

}

