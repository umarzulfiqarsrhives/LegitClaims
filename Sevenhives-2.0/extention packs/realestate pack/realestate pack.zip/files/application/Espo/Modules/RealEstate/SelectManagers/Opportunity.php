<?php


namespace Espo\Modules\RealEstate\SelectManagers;

class Opportunity extends \Espo\Modules\Crm\SelectManagers\Opportunity
{

}

