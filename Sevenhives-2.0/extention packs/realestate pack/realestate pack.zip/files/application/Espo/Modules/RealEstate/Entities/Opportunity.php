<?php


namespace Espo\Modules\RealEstate\Entities;

class Opportunity extends \Espo\Modules\Crm\Entities\Opportunity
{

}

