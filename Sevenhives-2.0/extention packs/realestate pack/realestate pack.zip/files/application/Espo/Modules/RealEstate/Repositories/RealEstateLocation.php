<?php

namespace Espo\Modules\RealEstate\Repositories;

class RealEstateLocation extends \Espo\Core\Repositories\CategoryTree
{

}
