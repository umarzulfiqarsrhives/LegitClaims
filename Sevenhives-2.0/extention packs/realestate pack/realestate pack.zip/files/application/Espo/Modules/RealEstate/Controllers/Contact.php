<?php


namespace Espo\Modules\RealEstate\Controllers;

class Contact extends \Espo\Modules\Crm\Controllers\Contact
{

}
