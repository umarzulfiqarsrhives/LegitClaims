<?php


namespace Espo\Modules\RealEstate\Controllers;

class Opportunity extends \Espo\Modules\Crm\Controllers\Opportunity
{

}
