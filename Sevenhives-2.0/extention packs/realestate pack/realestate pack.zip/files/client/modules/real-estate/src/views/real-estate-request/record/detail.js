

Espo.define('real-estate:views/real-estate-request/record/detail', 'views/record/detail', function (Dep) {

    return Dep.extend({

        bottomView: "real-estate:views/real-estate-request/record/detail-bottom"

    });

});
