

Espo.define('real-estate:views/real-estate-location/record/list-tree-item', 'views/record/list-tree-item', function (Dep) {

    return Dep.extend({

        listViewName: 'real-estate:views/real-estate-location/record/list-tree',

    });
});

