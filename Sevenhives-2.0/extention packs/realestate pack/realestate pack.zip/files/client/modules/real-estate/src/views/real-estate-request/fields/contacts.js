

Espo.define('real-estate:views/real-estate-request/fields/contacts', 'views/fields/link-multiple-with-primary', function (Dep) {

    return Dep.extend({

        primaryLink: 'contact'

    });

});
